import { Component, OnInit } from '@angular/core';
import { ApiService } from './shared/api.service';
import { AuthGuard } from './auth.guard';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'EMS_DashBoard';
  
  constructor(private api:ApiService, private auth:AuthGuard, private router:Router) { }
  
  ngOnInit(): void {

    let tempId = JSON.stringify(sessionStorage.getItem('EmployeeId'));
    let tempRole = JSON.stringify(sessionStorage.getItem('Role'));
    let EmployeeId = JSON.parse(tempId);
    let Role = JSON.parse(tempRole);

    console.log(EmployeeId)

    if(EmployeeId != null){
      this.auth.loggedIn = true;
    }

    if(!this.auth.loggedIn){
      this.router.navigate(['']);
    }

    if(Role == 1){
     this.api.verifyUser(1);
    }
    else if(Role == 2){
      this.api.verifyUser(2);
    }
    else{
      this.api.verifyUser(3);
    }

  }
}
